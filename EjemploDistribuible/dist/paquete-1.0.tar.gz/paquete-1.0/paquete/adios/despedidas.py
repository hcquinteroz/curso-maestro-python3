#Este es un módulo con funciones que saludan
def despedir():
    print("Hola. Me estoy despidiendo desde la función despedir del módulo despedidas")

class Despedida:
    def __init__(self):
        print("Hola. Me estoy despidiendo desde el init de la clase Despedida.")